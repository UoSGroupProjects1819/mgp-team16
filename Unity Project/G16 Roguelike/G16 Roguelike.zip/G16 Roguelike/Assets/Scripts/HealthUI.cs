﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthUI : MonoBehaviour
{

    public GameObject player;
    public GameObject[] hearts;

    void Update()
    {
        if (player.GetComponent<PlayerScript>().health >= 3)
        {
            hearts[2].SetActive(true);
        }
        else
        {
            hearts[2].SetActive(false);
        }

        if (player.GetComponent<PlayerScript>().health >= 2)
        {
            hearts[1].SetActive(true);
        }
        else
        {
            hearts[1].SetActive(false);
        }

        if (player.GetComponent<PlayerScript>().health >= 1)
        {
            hearts[0].SetActive(true);
        }
        else
        {
            hearts[0].SetActive(false);
        }
    }
}
